package com.example.salesapp

class UserInfo
{
    companion object{
        var mobile:String=""
        var itemId:Int=0
        var qty:Int=0
        var client_id:String="AWJDQncbA1oeVEdmnEG6BSoS0hpcArInqiaQEeFQncmgj7GzRfFwPTbXQB-GMKe5fefPvzc_Nvg2w3Iy"
    }
}