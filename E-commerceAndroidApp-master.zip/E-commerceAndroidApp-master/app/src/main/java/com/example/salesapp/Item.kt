package com.example.salesapp

class Item {
    var id:Int
    var name:String
    var price:Double
    var photo:String

    constructor(id:Int,name:String,price:Double,photo:String)
    {
        this.id=id
        this.name=name
        this.price=price
        this.photo=photo
    }
}